import { MAX_MONSTERS } from "./config";

/**
 * 몬스터 시스템
 * - 몬스터 생성
 * - 이동
 * - 상태이상
 * - 사망 처리
 * - 렌더
 */
export function createMonsterSystem({
  pathRef,
  monsterMapRef,
  monsterImageMapRef,
  stageRef,
  onMonsterDead, // 보상 / 미션 콜백
}) {
  const monstersRef = { current: [] };

  /* ======================
     몬스터 생성
  ====================== */

  function spawn(enemyId, { isBoss = false, isMission = false } = {}) {
    const base = monsterMapRef.current[enemyId];
    if (!base) return;

    const img = isMission
      ? monsterImageMapRef.current[`mission_${enemyId}`]
      : isBoss
      ? monsterImageMapRef.current[`boss_${enemyId}`]
      : monsterImageMapRef.current[enemyId];

    if (!img || !pathRef.current?.length) return;

    // 일반 웨이브 제한
    if (
      !isMission &&
      stageRef.current &&
      monstersRef.current.length >= stageRef.current.mapConfigJson.limitCount
    ) {
      return;
    }

    const hp = isBoss ? base.hp * 1 : base.hp;
    const speed = isBoss ? base.speed * 0.6 : base.speed;
    const rewardBit = isBoss ? base.rewardBit * 1 : base.rewardBit;

    const BASE_SIZE = 48;
    const size = isBoss ? BASE_SIZE * 1.5 : BASE_SIZE;

    monstersRef.current.push({
      id: Date.now() + Math.random(),

      // 위치
      x: pathRef.current[0].x,
      y: pathRef.current[0].y,
      pathIndex: 0,
      loopStartIndex: 2,

      // 타입
      isBoss,
      isMission,

      // 스탯
      hp,
      maxHp: hp,
      defense: base.defense,
      baseDefense: base.defense,
      baseSpeed: speed,
      speed,

      // 상태이상
      status: {
        slowUntil: 0,
        stunUntil: 0,
        defenseDownUntil: 0,
      },

      rewardBit,

      // 스프라이트
      img,
      frame: 0,
      timer: 0,
      frameDuration: isBoss ? 200 : 120,
      cols: 2,
      rows: 2,
      totalFrames: 4,

      size,
    });
  }

  /* ======================
     이동
  ====================== */

  function move(mon, delta) {
    const now = performance.now();

    if (mon.status.stunUntil > now) return;

    let currentSpeed = mon.baseSpeed;
    if (mon.status.slowUntil > now) {
      currentSpeed *= 0.5;
    }

    const nextIndex = mon.pathIndex + 1;
    const path = pathRef.current;

    if (!path[nextIndex]) {
      const idx = mon.loopStartIndex ?? 0;
      mon.pathIndex = idx;
      mon.x = path[idx].x;
      mon.y = path[idx].y;
      return;
    }

    const target = path[nextIndex];
    const dx = target.x - mon.x;
    const dy = target.y - mon.y;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist < 2) {
      mon.pathIndex++;
    } else {
      const move = currentSpeed * (delta / 16.67);
      mon.x += (dx / dist) * move;
      mon.y += (dy / dist) * move;
    }
  }

  /* ======================
     업데이트
  ====================== */

  function update(delta) {
    monstersRef.current.forEach((mon) => {
      // 애니메이션
      mon.timer += delta;
      if (mon.timer >= mon.frameDuration) {
        mon.frame = (mon.frame + 1) % mon.totalFrames;
        mon.timer = 0;
      }

      move(mon, delta);

      // 방어력 디버프 해제
      if (mon.status.defenseDownUntil < performance.now()) {
        mon.defense = mon.baseDefense;
      }
    });

    // 사망 처리
    monstersRef.current = monstersRef.current.filter((mon) => {
      if (mon.hp <= 0) {
        onMonsterDead?.(mon);
        return false;
      }
      return true;
    });
  }

  /* ======================
     렌더
  ====================== */

  function render(ctx) {
    monstersRef.current.forEach((mon) => {
      if (!mon.img || !mon.img.loaded) return;

      const fw = mon.img.width / mon.cols;
      const fh = mon.img.height / mon.rows;
      const col = mon.frame % mon.cols;
      const row = Math.floor(mon.frame / mon.cols);

      const targetSize = mon.size ?? 48;
      const scale = targetSize / Math.max(fw, fh);
      const drawW = fw * scale;
      const drawH = fh * scale;

      ctx.save();

      // 보스 흔들림
      if (mon.isBoss) {
        ctx.translate((Math.random() - 0.5) * 1.5, (Math.random() - 0.5) * 1.5);
      }

      // 체력바
      const hpBarWidth = drawW * 0.8;
      const hpRatio = Math.max(0, mon.hp) / mon.maxHp;

      ctx.fillStyle = "red";
      ctx.fillRect(
        mon.x - hpBarWidth / 2,
        mon.y - drawH / 2 - 8,
        hpBarWidth,
        4
      );

      ctx.fillStyle = "lime";
      ctx.fillRect(
        mon.x - hpBarWidth / 2,
        mon.y - drawH / 2 - 8,
        hpBarWidth * hpRatio,
        4
      );

      // 몬스터 이미지
      ctx.drawImage(
        mon.img,
        col * fw,
        row * fh,
        fw,
        fh,
        mon.x - drawW / 2,
        mon.y - drawH / 2,
        drawW,
        drawH
      );

      // 상태이상 시각 효과
      const now = performance.now();

      if (mon.status.slowUntil > now) {
        ctx.strokeStyle = "rgba(80,180,255,0.8)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(mon.x, mon.y, drawW / 2 + 6, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (mon.status.stunUntil > now) {
        ctx.strokeStyle = "rgba(255,215,0,0.9)";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(mon.x, mon.y, drawW / 2 + 10, 0, Math.PI * 2);
        ctx.stroke();
      }

      if (mon.status.defenseDownUntil > now) {
        ctx.strokeStyle = "rgba(180,80,255,0.8)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(mon.x, mon.y, drawW / 2 + 8, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.restore();
    });
  }

  /* ======================
     외부 접근
  ====================== */

  function getMonsters() {
    return monstersRef.current;
  }

  return {
    monstersRef,
    spawn,
    update,
    render,
    getMonsters,
  };
}
