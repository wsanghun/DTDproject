import {
  EFFECT_FRAME_CONFIG,
  EFFECT_SHEET_LAYOUT,
  EFFECT_FRAME_DURATION,
  IMPACT_SIZE_BY_TIER,
  TOWER_SIZE_BY_TIER,
  getEffectFrameInfo,
} from "./config";

export function createEffectSystem({ effectImageMapRef }) {
  const effectsRef = { current: [] };

  /* ======================
     이펙트 생성
  ====================== */

  function spawnAttackEffect(tower, target) {
    console.log("🔥 spawnAttackEffect", tower.towerIdx);
    if (!target) return;

    const effectImg = effectImageMapRef.current[tower.towerIdx];
    console.log("🔥 spawnAttackEffect", tower.towerIdx);
    if (!effectImg || !effectImg.loaded) return;

    // 🔥 레이저 (203)
    if (tower.towerIdx === 203) {
      effectsRef.current.push({
        id: Date.now() + Math.random(),
        type: "LASER",

        startX: tower.x,
        startY: tower.y,
        targetX: target.x,
        targetY: target.y,

        elapsed: 0,
        lifeTime: 300,

        tier: tower.tier,
        towerIdx: tower.towerIdx,
      });
      return;
    }

    // 🔹 일반 투사체
    const dx = target.x - tower.x;
    const dy = target.y - tower.y;
    const angle = Math.atan2(dy, dx);

    const muzzleOffset = (TOWER_SIZE_BY_TIER[tower.tier] ?? 40) / 2;

    const startX = tower.x + Math.cos(angle) * muzzleOffset;
    const startY = tower.y + Math.sin(angle) * muzzleOffset;

    const { frames } = getEffectFrameInfo(tower.towerIdx);

    effectsRef.current.push({
      id: Date.now() + Math.random(),

      x: startX,
      y: startY,
      startX,
      startY,

      target,
      speed: 6,

      img: effectImg,
      frame: 0,
      timer: 0,
      frameDuration: EFFECT_FRAME_DURATION,
      totalFrames: frames,

      tier: tower.tier,
      towerIdx: tower.towerIdx,
    });
  }

  function spawnEvolveEffect(x, y, tier) {
    effectsRef.current.push({
      id: Date.now() + Math.random(),
      type: "EVOLVE",

      x,
      y,
      tier,

      elapsed: 0,
      lifeTime: 700,
    });
  }

  /* ======================
     업데이트
  ====================== */

  function update(delta) {
    effectsRef.current.forEach((fx) => {
      fx.elapsed = (fx.elapsed ?? 0) + delta;

      if (fx.type === "LASER" || fx.type === "EVOLVE") {
        if (fx.elapsed > fx.lifeTime) fx.done = true;
        return;
      }

      // 이동형 투사체
      if (!fx.target) {
        fx.done = true;
        return;
      }

      const dx = fx.target.x - fx.x;
      const dy = fx.target.y - fx.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist < fx.speed) {
        fx.x = fx.target.x;
        fx.y = fx.target.y;
        fx.done = true;
        return;
      }

      fx.x += (dx / dist) * fx.speed;
      fx.y += (dy / dist) * fx.speed;

      fx.timer += delta;
      if (fx.timer >= fx.frameDuration) {
        fx.frame = (fx.frame + 1) % fx.totalFrames;
        fx.timer = 0;
      }
    });

    effectsRef.current = effectsRef.current.filter((fx) => !fx.done);
  }

  /* ======================
     렌더
  ====================== */

  function render(ctx) {
    effectsRef.current.forEach((fx) => {
      // ======================
      // 🔥 레이저
      // ======================
      if (fx.type === "LASER") {
        const pulse = 1 + Math.sin(performance.now() / 40) * 0.15;

        ctx.save();

        ctx.strokeStyle = "rgba(80,180,255,0.4)";
        ctx.lineWidth = 20 * pulse;
        ctx.shadowBlur = 25;
        ctx.beginPath();
        ctx.moveTo(fx.startX, fx.startY);
        ctx.lineTo(fx.targetX, fx.targetY);
        ctx.stroke();

        ctx.strokeStyle = "rgba(160,220,255,1)";
        ctx.lineWidth = 10 * pulse;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.moveTo(fx.startX, fx.startY);
        ctx.lineTo(fx.targetX, fx.targetY);
        ctx.stroke();

        ctx.restore();
        return;
      }

      // ======================
      // ✨ 진화 이펙트
      // ======================
      if (fx.type === "EVOLVE") {
        const progress = fx.elapsed / fx.lifeTime;
        const radius = 20 + progress * 35;
        const alpha = 1 - progress;
        const pulse = 1 + Math.sin(performance.now() / 60) * 0.2;

        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.translate(fx.x, fx.y);
        ctx.scale(pulse, pulse);

        ctx.strokeStyle = "white";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, Math.PI * 2);
        ctx.stroke();

        for (let i = 0; i < 8; i++) {
          const a = (Math.PI * 2 * i) / 8;
          const r = radius + 6;

          ctx.beginPath();
          ctx.fillStyle = "rgba(255,255,255,0.8)";
          ctx.arc(Math.cos(a) * r, Math.sin(a) * r, 3, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
        return;
      }

      // ======================
      // 🔹 일반 투사체
      // ======================
      if (!fx.img || !fx.img.loaded) return;

      const dx = fx.target.x - fx.x;
      const dy = fx.target.y - fx.y;
      const angle = Math.atan2(dy, dx);

      const { direction, frames } = getEffectFrameInfo(fx.towerIdx);
      const layout = EFFECT_SHEET_LAYOUT[fx.towerIdx];

      let fw, fh, sx, sy;
      const frameIdx = fx.frame;

      if (layout) {
        const { cols, rows } = layout;
        fw = fx.img.width / cols;
        fh = fx.img.height / rows;
        const col = frameIdx % cols;
        const row = Math.floor(frameIdx / cols);
        sx = col * fw;
        sy = row * fh;
      } else {
        fw = direction === "horizontal" ? fx.img.width / frames : fx.img.width;
        fh = direction === "vertical" ? fx.img.height / frames : fx.img.height;
        sx = direction === "horizontal" ? frameIdx * fw : 0;
        sy = direction === "vertical" ? frameIdx * fh : 0;
      }

      const baseSize = IMPACT_SIZE_BY_TIER[fx.tier] ?? 40;
      const scale = baseSize / Math.max(fw, fh);
      const drawW = fw * scale;
      const drawH = fh * scale;

      ctx.save();
      ctx.translate(fx.x, fx.y);

      if (fx.towerIdx !== 504) ctx.rotate(angle);

      ctx.drawImage(
        fx.img,
        sx,
        sy,
        fw,
        fh,
        -drawW / 2,
        -drawH / 2,
        drawW,
        drawH
      );

      ctx.restore();
    });
  }

  return {
    effectsRef,
    spawnAttackEffect,
    spawnEvolveEffect,
    update,
    render,
  };
}
