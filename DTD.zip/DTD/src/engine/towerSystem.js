import { MAX_TOWERS, TOWER_SIZE_BY_TIER } from "./config";

/**
 * 타워 시스템
 */
export function createTowerSystem({
  monsterSystem,
  effectSystem,
  towerImageMapRef,
  myTowersRef,
  onBitChange,
}) {
  const towersRef = { current: [] };

  /* ======================
     타워 설치
  ====================== */

  function buildTower(zone, towerMeta, bit) {
    if (bit < towerMeta.baseBuildCost) return null;
    if (towersRef.current.length >= MAX_TOWERS) return null;

    const occupied = towersRef.current.some(
      (t) => t.zoneX === zone.x && t.zoneY === zone.y
    );
    if (occupied) return null;

    const x = zone.x + zone.w / 2;
    const y = zone.y + zone.h / 2;

    const tower = {
      id: Date.now() + Math.random(),

      x,
      y,
      zoneX: zone.x,
      zoneY: zone.y,

      towerIdx: towerMeta.towerIdx,
      tier: towerMeta.tier,
      img: towerImageMapRef.current[towerMeta.towerIdx],

      range: towerMeta.baseRange,
      damage: towerMeta.currentDamage,
      attackSpeed: towerMeta.baseCooldown * 1000,
      lastAttackTime: 0,

      /* ===== 애니메이션 ===== */
      hasTarget: false,

      idleFrames: [0, 1],
      attackFrames: [2, 3],

      frameIndex: 0,
      animTimer: 0,

      frameDurationIdle: 15,
      frameDurationAttack: 10,

      cols: 2,
      rows: 2,
    };

    towersRef.current.push(tower);
    onBitChange(-towerMeta.baseBuildCost);
    return tower;
  }

  /* ======================
     업데이트 (상태만 결정)
  ====================== */

  function update(now) {
    const monsters = monsterSystem.getMonsters();

    towersRef.current.forEach((tower) => {
      const target = monsters.find((mon) => {
        const dx = mon.x - tower.x;
        const dy = mon.y - tower.y;
        return Math.hypot(dx, dy) <= tower.range;
      });

      tower.hasTarget = !!target;

      if (!target) return;
      if (now - tower.lastAttackTime < tower.attackSpeed) return;

      tower.lastAttackTime = now;

      const meta = myTowersRef.current.find(
        (t) => t.towerIdx === tower.towerIdx
      );
      if (!meta) return;

      applyDamage(target, tower);
      effectSystem.spawnAttackEffect(tower, target);
    });
  }

  /* ======================
     데미지
  ====================== */

  function applyDamage(mon, tower) {
    if (!mon || mon.hp <= 0) return;
    const dmg = Math.max(1, tower.damage - (mon.defense ?? 0));
    mon.hp -= dmg;
  }

  /* ======================
     렌더 (프리뷰 방식)
  ====================== */

  function render(ctx, selectedTowerId, delta) {
    towersRef.current.forEach((tower) => {
      if (!tower.img || !tower.img.loaded) return;

      const frames = tower.hasTarget ? tower.attackFrames : tower.idleFrames;

      const frameDuration = tower.hasTarget
        ? tower.frameDurationAttack
        : tower.frameDurationIdle;

      tower.animTimer += delta;

      if (tower.animTimer >= frameDuration) {
        tower.animTimer = 0;
        tower.frameIndex = (tower.frameIndex + 1) % frames.length;
      }

      const frame = frames[tower.frameIndex];

      const fw = tower.img.width / tower.cols;
      const fh = tower.img.height / tower.rows;

      const col = frame % tower.cols;
      const row = Math.floor(frame / tower.cols);

      const size = TOWER_SIZE_BY_TIER[tower.tier] ?? 56;

      ctx.drawImage(
        tower.img,
        col * fw,
        row * fh,
        fw,
        fh,
        tower.x - size / 2,
        tower.y - size / 2,
        size,
        size
      );
    });
  }

  /* ======================
     유틸
  ====================== */

  function getTowerAt(x, y) {
    return towersRef.current.find((t) => {
      const dx = x - t.x;
      const dy = y - t.y;
      const r = (TOWER_SIZE_BY_TIER[t.tier] ?? 56) / 2;
      return dx * dx + dy * dy <= r * r;
    });
  }

  function isOccupied(x, y, radius = 24) {
    return towersRef.current.some((t) => {
      const dx = t.x - x;
      const dy = t.y - y;
      return Math.hypot(dx, dy) < radius * 2;
    });
  }

  return {
    towersRef,
    buildTower,
    update,
    render,
    getTowerAt,
    isOccupied,
  };
}
