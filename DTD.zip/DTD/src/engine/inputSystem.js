const PREVIEW_FRAMES = [0, 1]; // 2×2 중 상단 두 프레임
const FRAME_DURATION = 200;

export function createInputSystem({
  canvasRef,
  buildZonesRef,
  buildTowerRef, // 현재 선택된 카드 (ref)
  towerImageMapRef,
  pathRef,
  towerSystem,
}) {
  const mouse = { x: 0, y: 0 };
  let time = 0;

  function onMouseMove(e) {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) * canvas.width) / rect.width;
    mouse.y = ((e.clientY - rect.top) * canvas.height) / rect.height;
  }

  function attach() {
    canvasRef.current?.addEventListener("mousemove", onMouseMove);
  }

  function detach() {
    canvasRef.current?.removeEventListener("mousemove", onMouseMove);
  }

  function getSnapZone() {
    return buildZonesRef.current.find(
      (z) =>
        mouse.x >= z.x &&
        mouse.x <= z.x + z.w &&
        mouse.y >= z.y &&
        mouse.y <= z.y + z.h
    );
  }

  function getRotation() {
    // 가장 가까운 path segment 방향 기준 회전
    let closest = null;
    let minDist = Infinity;

    for (let i = 0; i < pathRef.current.length - 1; i++) {
      const p1 = pathRef.current[i];
      const p2 = pathRef.current[i + 1];
      const dx = p2.x - p1.x;
      const dy = p2.y - p1.y;

      const cx = p1.x;
      const cy = p1.y;
      const dist = Math.hypot(mouse.x - cx, mouse.y - cy);

      if (dist < minDist) {
        minDist = dist;
        closest = Math.atan2(dy, dx);
      }
    }
    return closest ?? 0;
  }

  function update(delta) {
    time += delta;
  }

  function render(ctx) {
    const buildTower = buildTowerRef.current;
    if (!buildTower) return;

    const img = towerImageMapRef.current[buildTower.towerIdx];
    if (!img || !img.loaded) return;

    const zone = getSnapZone();

    let canBuild = false;
    let snapX = mouse.x;
    let snapY = mouse.y;

    if (zone) {
      snapX = zone.x + zone.w / 2;
      snapY = zone.y + zone.h / 2;

      // ⭐ 이미 타워가 있는지 체크
      const occupied = towerSystem.isOccupied(snapX, snapY);
      canBuild = !occupied;
    }

    const x = zone ? zone.x + zone.w / 2 : mouse.x;
    const y = zone ? zone.y + zone.h / 2 : mouse.y;

    const size = 48;
    const floatY = Math.sin(time * 0.005) * 4;

    ctx.save();
    ctx.translate(x, y + floatY);

    ctx.globalAlpha = 0.7;

    // 색상 오버레이
    // ======================
    // 🎞 2×2 프리뷰 프레임 계산
    // ======================
    const cols = 2;
    const rows = 2;

    const frameW = img.width / cols;
    const frameH = img.height / rows;

    const frameIndex =
      PREVIEW_FRAMES[Math.floor(time / FRAME_DURATION) % PREVIEW_FRAMES.length];

    const col = frameIndex % cols; // 0 or 1
    const row = Math.floor(frameIndex / cols); // 항상 0 (상단만)

    const sx = col * frameW;
    const sy = row * frameH;

    ctx.drawImage(
      img,
      sx,
      sy,
      frameW,
      frameH,
      -size / 2,
      -size / 2,
      size,
      size
    );

    ctx.globalCompositeOperation = "source-atop";
    ctx.fillStyle = canBuild ? "rgba(0,255,0,0.35)" : "rgba(255,0,0,0.35)";
    ctx.fillRect(-size / 2, -size / 2, size, size);

    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;

    // 테두리
    ctx.strokeStyle = canBuild ? "#00ff88" : "#ff4444";
    ctx.lineWidth = 2;
    ctx.strokeRect(-size / 2, -size / 2, size, size);

    ctx.restore();
  }

  return {
    attach,
    detach,
    update,
    render,
    towerSystem,
  };
}
