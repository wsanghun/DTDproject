/**
 * 웨이브 시스템
 * - 웨이브 순차 진행
 * - 몬스터 스폰 타이밍 관리
 */
export function createWaveSystem({
  wavesRef,
  monsterSystem,
  gameSpeedRef,
  onWaveChange,
}) {
  const stateRef = {
    currentWave: 0,
    spawnedCount: 0,
    lastSpawnTime: 0,
    running: false,
  };

  function start() {
    stateRef.currentWave = 0;
    stateRef.spawnedCount = 0;
    stateRef.lastSpawnTime = 0;
    stateRef.running = true;

    onWaveChange?.(1);
  }

  function update(now) {
    if (!stateRef.running) return;

    const wave = wavesRef.current[stateRef.currentWave];
    if (!wave) {
      stateRef.running = false;
      return;
    }

    const interval = wave.interval / (gameSpeedRef?.current ?? 1);
    const totalCount = wave.count ?? 10;

    if (now - stateRef.lastSpawnTime >= interval) {
      monsterSystem.spawn(Number(wave.enemyId));
      stateRef.spawnedCount++;
      stateRef.lastSpawnTime = now;
    }

    // 웨이브 종료
    if (stateRef.spawnedCount >= totalCount) {
      stateRef.currentWave++;
      stateRef.spawnedCount = 0;
      stateRef.lastSpawnTime = now;

      onWaveChange?.(stateRef.currentWave + 1);
    }
  }

  function isRunning() {
    return stateRef.running;
  }

  return {
    start,
    update,
    isRunning,
  };
}
