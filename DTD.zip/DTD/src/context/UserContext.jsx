import { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";

const UserContext = createContext(null);

export function UserProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        // 서버가 살아있으면 유저 정보 가져옴
        const res = await axios.get("/api/users/me", {
          withCredentials: true,
          timeout: 3000, // ⭐ 서버가 죽었을 때 3초 후 자동 종료 (중요)
        });

        setUser(res.data);
      } catch (err) {
        console.warn("서버 응답 없음 → 비로그인 상태로 계속 진행");
        setUser(null); // ⭐ 서버 꺼져 있어도 화면은 뜨게 해야 함
      } finally {
        setLoading(false); // ⭐ 절대 빠지면 안 됨. 화면을 띄우는 핵심.
      }
    };

    fetchUser();
  }, []);

  return (
    <UserContext.Provider value={{ user, setUser, loading }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  return useContext(UserContext);
}
