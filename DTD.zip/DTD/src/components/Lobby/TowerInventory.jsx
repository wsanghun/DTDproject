// TowerInventory.jsx
import { useState, useEffect } from "react";
import { useMyTowers } from "../../context/UserTowerContext";
import { useTowers } from "../../context/TowerContext";
import { useUser } from "../../context/UserContext";
import TowerDetail from "./TowerDetail";
import "../../css/TowerInventory.css";

export default function TowerInventory({ onBack }) {
  // ⭐ refreshTowers 포함해서 가져오기
  const { towers, loading, refreshTowers } = useTowers();
  const { myTowers } = useMyTowers();
  const { user } = useUser();

  // ✅ 선택된 건 "객체" 말고 towerIdx만 저장
  const [selectedIdx, setSelectedIdx] = useState(null);

  // ESC 닫기
  useEffect(() => {
    const handleESC = (e) => e.key === "Escape" && onBack();
    window.addEventListener("keydown", handleESC);
    return () => window.removeEventListener("keydown", handleESC);
  }, [onBack]);

  if (loading) {
    return (
      <div className="inventory-container">
        <h2>Loading...</h2>
      </div>
    );
  }

  // ✅ 항상 towers 배열에서 현재 선택된 타워를 찾아서 사용
  const current =
    towers.find((t) => t.towerIdx === selectedIdx) ?? towers[0] ?? null;

  // 강화 레벨 조회
  const getUserTier = (towerIdx) => {
    const info = myTowers.find((t) => t.towerIdx === towerIdx);
    return info?.currentLevel ?? 0;
  };

  return (
    <div className="inventory-container">
      {/* 좌측 디테일 패널 */}
      <div className="left-panel">
        {current && (
          <TowerDetail
            tower={current}
            userTier={getUserTier(current.towerIdx)}
            refreshTowers={refreshTowers}
          />
        )}
      </div>

      {/* 우측 그리드 */}
      <div className="right-panel">
        <div className="inventory-grid">
          {towers.map((tower) => {
            const isSelected =
              (selectedIdx ?? current?.towerIdx) === tower.towerIdx;
            const userTier = getUserTier(tower.towerIdx);
            const canEnhance = user.gold >= tower.nextLevelCost;

            return (
              <div
                key={tower.towerIdx}
                className={`
                  inventory-card
                  tier-${userTier}
                  ${isSelected ? "selected" : ""}
                  ${canEnhance ? "can-enhance" : ""}
                `}
                onClick={() => setSelectedIdx(tower.towerIdx)}
              >
                {/* 대표 표시 스타 */}
                {user?.mainTower?.tower?.idx === tower.towerIdx && (
                  <div className="main-star">★</div>
                )}

                <img
                  src={
                    new URL(
                      `../../assets/images/Towerimages/tier${tower.tier}/${tower.towerIdx}.png`,
                      import.meta.url
                    ).href
                  }
                  className="tower-img"
                />
              </div>
            );
          })}
        </div>
      </div>

      {/* 아래 버튼 */}
      <button className="back-btn-bottom" onClick={onBack}>
        ← 돌아가기 (ESC)
      </button>
    </div>
  );
}
