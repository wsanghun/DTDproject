export default function TowerDex({ onBack }) {
  return (
    <div className="subscreen">
      <h2>도감</h2>
      <button onClick={onBack}>뒤로가기</button>
    </div>
  );
}
