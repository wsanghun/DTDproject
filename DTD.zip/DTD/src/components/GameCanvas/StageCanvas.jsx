import { useEffect, useRef, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

import "../../css/stage.css";
import stage1 from "../../stages/Stage1";
import stage1Map from "../../assets/Maps/Stage1/1-1.png";

import { useGameLoop } from "../../engine/useGameLoop";
import { createMonsterSystem } from "../../engine/monsterSystem";
import { createTowerSystem } from "../../engine/towerSystem";
import { createEffectSystem } from "../../engine/effectSystem";

import { MAX_MONSTERS } from "../../engine/config";

import { createWaveSystem } from "../../engine/waveSystem";
import { createInputSystem } from "../../engine/inputSystem";

import TowerCardPanel from "../UI/TowerCardPanel";

export default function StageCanvas() {
  const { stageId } = useParams();
  /* ======================
     Refs
  ====================== */
  const canvasRef = useRef(null);
  const gameSpeedRef = useRef(1);
  const effectImageMapRef = useRef({});

  const pathRef = useRef([]);
  const buildZonesRef = useRef([]);

  const monsterMapRef = useRef({});
  const monsterImageMapRef = useRef({});
  const towerImageMapRef = useRef({});
  const myTowersRef = useRef([]);
  const wavesRef = useRef([]);
  const [myTowers, setMyTowers] = useState([]);

  const stageRef = useRef(null);

  /* ======================
     UI State
  ====================== */
  const [bit, setBit] = useState(0);
  const [buildTower, setBuildTower] = useState(null);
  const [selectedPlacedTower, setSelectedPlacedTower] = useState(null);
  const mapImgRef = useRef(null);

  useEffect(() => {
    const img = new Image();
    img.src = stage1Map;
    img.onload = () => {
      mapImgRef.current = img;
    };
  }, []);

  /* ======================
     엔진 생성
  ====================== */
  const effectSystem = useRef(
    createEffectSystem({
      effectImageMapRef,
    })
  ).current;

  const monsterSystem = useRef(
    createMonsterSystem({
      pathRef,
      monsterMapRef,
      monsterImageMapRef,
      stageRef,
      onMonsterDead: (mon) => {
        setBit((prev) => prev + (mon.rewardBit ?? 0));
      },
    })
  ).current;

  const towerSystem = useRef(
    createTowerSystem({
      monsterSystem,
      effectSystem,
      towerImageMapRef,
      myTowersRef,
      clearedMissionsRef: { current: [] }, // 미션 시스템 붙일 자리
      onBitChange: (delta) => setBit((prev) => prev + delta),
    })
  ).current;

  /* ======================
     Stage / 데이터 로딩
  ====================== */
  useEffect(() => {
    async function loadStage() {
      // JS 지형
      pathRef.current = stage1.path;
      buildZonesRef.current = stage1.buildZones;

      // API 스테이지
      const stageRes = await axios.get(`/api/stages/${stageId}`);
      stageRef.current = stageRes.data;

      const mapConfig =
        typeof stageRes.data.mapConfigJson === "string"
          ? JSON.parse(stageRes.data.mapConfigJson)
          : stageRes.data.mapConfigJson;

      setBit(mapConfig.startBit ?? 0);
      wavesRef.current = mapConfig.waves ?? [];

      // ⭐ 웨이브 시작
      if (wavesRef.current.length > 0) {
        waveSystem.start();
      }

      // 몬스터
      const monsterRes = await axios.get("/api/monsters");
      monsterRes.data.forEach((m) => {
        monsterMapRef.current[m.idx] = m;

        const img = new Image();
        img.onload = () => (img.loaded = true);
        img.src = `/Monsters/stage${stageId}/${m.imageFile}.PNG`;
        monsterImageMapRef.current[m.idx] = img;
      });

      // 타워
      const towerRes = await axios.get("/api/towers");
      myTowersRef.current = towerRes.data;
      setMyTowers(towerRes.data);

      towerRes.data.forEach((t) => {
        const img = new Image();
        img.onload = () => (img.loaded = true);
        img.src = `/Towers/tier${t.tier}/${t.towerIdx}.PNG`;
        towerImageMapRef.current[t.towerIdx] = img;

        const effectImg = new Image();
        effectImg.onload = () => (effectImg.loaded = true);
        effectImg.src = `/Towers/effects/${t.towerIdx}.png`;
        effectImageMapRef.current[t.towerIdx] = effectImg;
      });
    }

    loadStage();
  }, [stageId]);

  /* ======================
     입력 처리
  ====================== */
  /*---------------esc----------------*/
  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.key === "Escape") {
        setBuildTower(null);
        setSelectedPlacedTower(null);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const getMousePos = (e) => {
      const rect = canvas.getBoundingClientRect();
      return {
        x: ((e.clientX - rect.left) * canvas.width) / rect.width,
        y: ((e.clientY - rect.top) * canvas.height) / rect.height,
      };
    };

    const onClick = (e) => {
      const { x, y } = getMousePos(e);

      // 설치된 타워 선택
      const tower = towerSystem.getTowerAt(x, y);
      if (tower) {
        setSelectedPlacedTower(tower);
        return;
      }

      // 설치
      if (!buildTower) return;

      const zone = buildZonesRef.current.find(
        (z) => x >= z.x && x <= z.x + z.w && y >= z.y && y <= z.y + z.h
      );
      if (!zone) return;

      const newTower = towerSystem.buildTower(zone, buildTower, bit);
      if (newTower) {
        setSelectedPlacedTower(newTower);
      }
    };

    canvas.addEventListener("click", onClick);
    return () => canvas.removeEventListener("click", onClick);
  }, [buildTower, bit, towerSystem]);

  const buildTowerRef = useRef(null);

  useEffect(() => {
    buildTowerRef.current = buildTower;
  }, [buildTower]);

  const inputSystem = useRef(
    createInputSystem({
      canvasRef,
      buildZonesRef,
      buildTowerRef,
      towerImageMapRef,
      pathRef,
      towerSystem,
    })
  ).current;

  //마운트 / 언마운트
  useEffect(() => {
    inputSystem.attach();
    return () => inputSystem.detach();
  }, [inputSystem]);

  const waveSystem = useRef(
    createWaveSystem({
      wavesRef,
      monsterSystem,
      gameSpeedRef,
      onWaveChange: (wave) => {
        console.log("🌊 Wave:", wave);
      },
    })
  ).current;

  /* ======================
     게임 루프
  ====================== */
  useGameLoop({
    canvasRef,
    gameSpeedRef,
    systems: {
      map: {
        render(ctx) {
          const img = mapImgRef.current;
          if (!img || !img.complete) return;
          ctx.drawImage(img, 0, 0, 1536, 900);
        },
      },
      wave: waveSystem,
      monster: monsterSystem,
      tower: towerSystem,
      effect: effectSystem,
      input: inputSystem,
      ui: {
        selectedTowerId: selectedPlacedTower?.id,
      },
    },
    onGameOver: () => monsterSystem.monstersRef.current.length >= MAX_MONSTERS,
  });

  /* ======================
     UI
  ====================== */
  return (
    <div className="game-container">
      <canvas ref={canvasRef} width={1536} height={900} />

      {/* 우측 상단 HUD */}
      <div className="hud top-right">
        <div>BIT: {bit}</div>
        <div>
          몬스터 {monsterSystem.monstersRef.current.length} / {MAX_MONSTERS}
        </div>

        {[1, 3, 5].map((s) => (
          <button
            key={s}
            onClick={() => (gameSpeedRef.current = s)}
            className={gameSpeedRef.current === s ? "active" : ""}
          >
            {s}x
          </button>
        ))}
      </div>
      <TowerCardPanel
        towers={myTowers}
        buildTower={buildTower}
        setBuildTower={setBuildTower}
        setSelectedPlacedTower={setSelectedPlacedTower}
      />
    </div>
  );
}
