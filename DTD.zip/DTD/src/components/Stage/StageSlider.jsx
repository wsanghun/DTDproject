import "../../css/StageSlider.css";
import StageCard from "./StageCard";
import { useState } from "react";

export default function StageSlider({ stage, total }) {
  const [index, setIndex] = useState(0);

  const goLeft = () => index > 0 && setIndex(index - 1);
  const goRight = () => index < total - 1 && setIndex(index + 1);

  return (
    <div className="slider-wrapper">
      {/* 왼쪽 카드 */}
      {index > 0 ? (
        <StageCard
          label={`${stage}-${index}`}
          size="small"
          isLocked={true}
          stars={2}
          onClick={() => setIndex(index - 1)}
        />
      ) : (
        <div className="stage-card placeholder small"></div>
      )}

      {/* 중앙 카드 */}
      <StageCard
        label={`${stage}-${index + 1}`}
        size="big"
        isLocked={true}
        stars={3}
      />

      {/* 오른쪽 카드 */}
      {index < total - 1 ? (
        <StageCard
          label={`${stage}-${index + 2}`}
          size="small"
          isLocked={true}
          stars={2}
          onClick={() => setIndex(index + 1)}
        />
      ) : (
        <div className="stage-card placeholder small"></div>
      )}
    </div>
  );
}
