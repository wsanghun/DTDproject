// src/components/Stage/StageSelect.jsx
import StageSlider from "./StageSlider";
import StageCard from "./StageCard";
import "../../css/StageSelect.css";

export default function StageSelect({ onBack, onStageSelect }) {
  return (
    <div className="stage-overlay">
      <div className="stage-title">1 스테이지</div>

      {/* 스테이지 1-1 */}
      <StageCard
        label="시작의 숲"
        size="big"
        isLocked={false}
        stars={3}
        onClick={() => onStageSelect("1")} // ⭐ 이동 실행!
      />

      <button className="back-btn" onClick={onBack}>
        돌아가기
      </button>
    </div>
  );
}
